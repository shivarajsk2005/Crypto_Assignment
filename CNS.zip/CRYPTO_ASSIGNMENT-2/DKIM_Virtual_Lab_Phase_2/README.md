# DKIM Virtual Laboratory – Phase 2

A classroom simulation of DKIM signing and verification.

DKIM is not an encryption/decryption algorithm, so the lab visualizes digital signing, transmission, verification, and tampering detection.

## Run
```bash
pip install -r requirements.txt
python app.py
```
Then open `http://127.0.0.1:5000`.

## Demonstration
1. Use the default Shivaraj → Sathwik email.
2. Click **Generate DKIM Signature**.
3. **Non** mode is selected by default and sends the signed message directly to the receiver. Click **Verify DKIM / Check for Tampering** → no tampering detected.
4. Select **Modify**, edit the intercepted message, and click **Send Changed Message to Receiver**.
5. The receiver's message is read-only. Click **Verify DKIM / Check for Tampering** → tampering detected if the message was changed.
6. Capture screenshots for the PDF submission.
